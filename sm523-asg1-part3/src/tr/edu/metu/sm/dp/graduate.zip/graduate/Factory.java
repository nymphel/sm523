package tr.edu.metu.sm.dp.graduate;

public interface Factory {
	
	public Course produceCourse();
	public Paper producePaper();
	public Earning produceEarning();

}
