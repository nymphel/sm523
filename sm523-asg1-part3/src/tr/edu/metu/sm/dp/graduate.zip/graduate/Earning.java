package tr.edu.metu.sm.dp.graduate;

public interface Earning {
	
	public String showEarning();

}
