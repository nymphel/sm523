package tr.edu.metu.sm.dp.graduate;

public class EarningPhd implements Earning {

	@Override
	public String showEarning() {
		System.out.println("EarningPhd->showEarning");
		return null;
	}

}
