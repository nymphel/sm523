package tr.edu.metu.sm.dp.graduate;

public class EarningMsWithThesis implements Earning {

	@Override
	public String showEarning() {
		System.out.println("EarningMsWithThesis->showEarning");
		return null;
	}

}
