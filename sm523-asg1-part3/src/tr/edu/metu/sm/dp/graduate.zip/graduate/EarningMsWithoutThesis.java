package tr.edu.metu.sm.dp.graduate;

public class EarningMsWithoutThesis implements Earning {

	@Override
	public String showEarning() {
		System.out.println("EarningMsWithoutThesis->showEarning");
		return null;
	}

}
